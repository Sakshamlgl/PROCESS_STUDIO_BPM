# Verification evidence — version 2.0

Verified 4 November 2026.

## Automated checks

- 48 Python tests passed: compiler nesting, token semantics, deadlock counterexamples, graph/XML validation, transformations, immutable bases, real HTTP persistence, stale revisions, concurrent saves, conflict repair, soft-delete restore, backup roundtrip/rollback, legacy migration, future-schema rejection, generation contracts, exact source evidence and fingerprint reproducibility.
- 10 JavaScript tests passed: simulation interleavings and token multiplicity; stale action rejection; real bpmn-moddle parsing of three sample diagrams; sequence-flow and lane DI coverage; official layout preservation; metamodel/XML type mapping; create/replace rule contexts.
- Vite production build passed: 412 modules transformed; modeler, diagram engine, metamodel and application split into separate bundles; no chunk-size advisory after splitting.
- Dependency installation reported zero vulnerabilities at installation. No claim is made that dependencies will remain vulnerability-free indefinitely.

## Browser checks

Generated a custom returns process, replaced an activity in the description, verified preview invalidation, regenerated and saved the changed diagram. Reopened the original description from the saved family. Created a contextual variant through visual operation cards; preview showed the inserted activity and changed connections; saved derived view had no modeling palette. Validated the entire family and completed variant simulation.

Verified source-linked preview activity counts, persisted evidence in the inspector, edited a base name and documentation, saw an evidence-change warning, saved a new revision and completed base simulation. Verified purchase-to-pay generation rendered five named swimlanes and its activities. Browser testing also identified editor type-name/context mismatches; regression tests were added and those paths rechecked after correction.

Final task-type replacement and release screenshots are captured with the delivered workspace when available. See the final screenshots in this directory.

## Explicit limits

No live external model credentials were configured. Natural-language pipeline tests use a clearly designated local provider fixture and mocked responses for validation/repair behavior. They do not establish real-model semantic accuracy, latency or cost. You must configure/test your own endpoint.

No external Camunda deployment, full OMG conformance certification, independent usability study, industrial case study, penetration test, multi-user load test, or comparison benchmark was performed. Token analysis covers the declared acyclic subset and bounded exploration only. Source-evidence matching checks exact presence, not semantic entailment.

Final browser acceptance: task-type replacement from service to manual retained activity ID N3; saving the changed base preserved the existing Business warranty variant, and both base and variant passed the family release check. The final workspace screenshot is workspace-v2.png.
