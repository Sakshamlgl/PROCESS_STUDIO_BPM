# User guide

## Author a process

Use New family for a blank description, From description to revise the current family's original input, or Import BPMN for an existing supported model. Natural-language mode requires your connected model. Structured mode compiles offline.

Name activities as verb + business object. Make decision alternatives and concurrency explicit. Generate a preview, inspect assumptions and activity evidence, then create the family. Editing the description invalidates the previous preview. Regeneration creates a separate family so existing variants cannot accidentally acquire unrelated regenerated IDs.

## Work on the canvas

Select an element directly or in Inspect's directory. Update name, supported activity type and documentation. Apply changes edits the canvas; Save base creates a persistent revision and propagates recipes. Task-type replacement retains the task's ID. Undo/redo are modeler operations. Ctrl/Cmd+S saves. The initial readable view may not show the whole process: pan or choose Fit for an overview. Arrange computes layout in a Worker; unsupported geometry retains the existing valid diagram.

Source evidence refers to the original saved description. A changed name/type produces a warning; a source quote alone is not evidence that the updated business logic is correct. BPMN/SVG export uses the current displayed diagram.

## Configure a variant

Choose + Variant, name the context, add context key/value fields, and build a recipe. Add a change, choose the target by ID or canvas click, enter the operation details, and save the change card. Reorder cards with arrows; stable operation IDs keep inserted-task references intact. Preview changes before saving. Advanced JSON is optional.

INSERT adds an activity after a node with one outgoing flow. DELETE bridges a single-in/single-out activity. MODIFY changes a label. MOVE relocates an activity after a single-outgoing destination. Graph validation rejects invalid results. Context values are metadata, not automatically enforced regulations.

Select a saved variant in the family strip to inspect a read-only derived model. Its recipe remains editable in Variants. Compare shows added/removed/changed activities and connection differences. Duplicate creates a new recipe draft. Move to trash is recoverable from History.

## Evolve and repair

A base save previews which recipes will conflict. If you proceed, the recipes remain present. Select a conflicted variant to see the base used as a repair reference, edit missing targets, preview, and save the repaired recipe. Another window's newer base/variant causes a version conflict; reload rather than overwrite it.

## Verify and simulate

Analyze the current diagram to inspect graph errors, complete/incomplete state exploration, deadlocks, unfired elements and a counterexample trace when available. Simulation is enabled only for a completely analyzed sound model. Click an enabled activity or a gateway alternative; parallel joins wait for all incoming branches. Modeling is paused during simulation. Export a trace to keep the run.

Validate all saved variants checks the whole family. A failed/conflicted/incomplete model blocks a successful handoff result. A successful result exports the backup and a manifest fingerprint identifying base revision, graph hash, recipe/context hashes and variant versions. This is a control-flow check, not an execution or regulatory certificate.

## Recover work

Unsaved canvas edits are stored as local recovery drafts. Normal navigation flushes the current draft before leaving. Recovery offers the draft with its original base revision; review it before saving against a newer base. Browser storage is best-effort; a sudden crash during the brief debounce window may lose the latest movement. Export BPMN for an independent copy.

History lists historical base snapshots, recoverable variants and the last 100 audit entries. Complete backups include all audit entries. Restore backup imports into a new family. For the complete workspace use the consistent SQLite backup tool. API keys are outside every backup.
