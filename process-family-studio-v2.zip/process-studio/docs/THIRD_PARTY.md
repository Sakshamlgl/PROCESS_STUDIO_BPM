# Third-party components

Keep bpmn.io attribution visible. Direct and transitive dependency versions are locked in frontend/package-lock.json. Available license and notice texts are included in third-party-licenses/. No Camunda affiliation is implied.

| Package | Version | License declaration |
|---|---|---|
| @bpmn-io/diagram-js-ui | 0.2.4 | MIT |
| @esbuild/win32-x64 | 0.25.12 | MIT |
| @rollup/rollup-win32-x64-gnu | 4.67.5 | MIT |
| @rollup/rollup-win32-x64-msvc | 4.67.5 | MIT |
| @types/estree | 1.0.10 | MIT |
| bpmn-auto-layout | 1.3.0 | MIT |
| bpmn-js | 18.31.1 | SEE LICENSE IN LICENSE |
| bpmn-moddle | 10.3.1 | MIT |
| clsx | 2.1.1 | MIT |
| diagram-js | 15.28.1 | MIT |
| diagram-js-direct-editing | 3.6.0 | MIT |
| didi | 11.0.1 | MIT |
| domify | 3.0.0 | MIT |
| esbuild | 0.25.12 | MIT |
| fdir | 6.5.0 | MIT |
| htm | 3.1.1 | Apache-2.0 |
| ids | 3.0.2 | MIT |
| inherits-browser | 0.1.0 | ISC |
| jsx-runtime | 1.0.0 | MIT |
| min-dash | 5.1.0 | MIT |
| min-dom | 5.3.0 | MIT |
| moddle | 8.2.1 | MIT |
| moddle-xml | 12.3.2 | MIT |
| nanoid | 3.3.20 | MIT |
| object-refs | 0.4.0 | MIT |
| path-intersection | 4.2.1 | MIT |
| picocolors | 1.1.1 | ISC |
| picomatch | 4.0.7 | MIT |
| postcss | 8.5.32 | MIT |
| preact | 10.29.8 | MIT |
| preact-compat | 4.0.0 | MIT |
| preact-debug | 1.0.0 | MIT |
| preact-devtools | 1.0.0 | MIT |
| preact-hooks | 0.1.0 | MIT |
| prettier | 3.9.10 | MIT |
| rollup | 4.67.5 | MIT |
| saxen | 11.2.0 | MIT |
| source-map-js | 1.2.2 | BSD-3-Clause |
| test-utils | 0.1.0 | MIT |
| tiny-svg | 4.1.4 | MIT |
| tinyglobby | 0.2.17 | MIT |
| vite | 6.4.5 | MIT |
